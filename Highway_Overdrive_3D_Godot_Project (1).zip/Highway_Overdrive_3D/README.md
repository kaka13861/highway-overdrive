# Highway Overdrive 3D — Godot starter project

An original, simple 3D arcade highway-racing prototype. It uses primitive 3D shapes, touch buttons, traffic, coins, nitro, and a basic police-pursuit/heat mechanic. It is inspired by the broad arcade-racing genre and does not include Asphalt's copyrighted cars, maps, branding, or assets.

## Open and run on PC
1. Install Godot 4.2 or newer.
2. Extract this ZIP.
3. In Godot Project Manager, choose **Import** and select `project.godot`.
4. Press **F6** or **F5** to run.

## Export an Android APK
1. Install Godot 4.2+ and its matching export templates.
2. In Godot, open **Editor > Manage Export Templates** and install the matching templates.
3. Install Android Studio / Android SDK and configure the Android SDK paths in Godot Editor Settings.
4. Open **Project > Export**, add an **Android** preset, and configure the package name (for example `com.example.highwayoverdrive`).
5. Export a debug APK for testing, or configure signing for a release APK.
6. Install the APK on your Android device. Enable installation from the source you use if Android asks.

The APK is not prebuilt in this package: exporting requires the Godot Android templates and Android SDK on your computer.

## Controls
- Touch: LEFT, RIGHT, NITRO, PAUSE
- Keyboard: Left/Right arrows to change lanes. Space activates nitro in editor builds only if keyboard handling is added later.

## Current prototype limitations
- Uses primitive placeholder cars and scenery rather than polished art assets.
- Core loop includes traffic, coins, nitro, collisions, and pursuit heat.
- A production game would need sound, menus, multiple levels, save data, car handling/upgrade systems, optimized assets, device testing, and more robust gameplay balancing.
