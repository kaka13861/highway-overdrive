extends Node3D

const LANES := [-3.2, 0.0, 3.2]
const PLAYER_Z := 5.0
const ROAD_LENGTH := 220.0

var player_lane := 1
var player: Node3D
var camera_3d: Camera3D
var road_root: Node3D
var object_root: Node3D
var ui_layer: CanvasLayer
var distance := 0.0
var coins := 0
var nitro := 100.0
var heat := 0.0
var speed := 28.0
var boost_time := 0.0
var spawn_timer := 0.0
var coin_timer := 0.0
var police_timer := 0.0
var game_over := false
var paused_game := false
var hud_label: Label
var message_label: Label
var overlay: ColorRect
var start_button: Button
var nitro_button: Button
var pause_button: Button
var left_button: Button
var right_button: Button
var road_marks: Array[Node3D] = []
var traffic: Array[Dictionary] = []
var touch_start := Vector2.ZERO

func _ready() -> void:
	_build_world()
	_build_ui()
	_update_hud()
	set_process(true)

func _build_world() -> void:
	var env := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_COLOR
	environment.background_color = Color(0.45, 0.72, 0.9)
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color(0.7, 0.75, 0.82)
	environment.ambient_light_energy = 0.8
	env.environment = environment
	add_child(env)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52, -25, 0)
	sun.light_energy = 1.3
	add_child(sun)

	road_root = Node3D.new()
	road_root.name = "Road"
	add_child(road_root)
	object_root = Node3D.new()
	object_root.name = "WorldObjects"
	add_child(object_root)

	_make_box(road_root, "RoadSurface", Vector3(10.5, 0.25, ROAD_LENGTH), Vector3(0, -0.2, -75), Color(0.16, 0.18, 0.21))
	_make_box(road_root, "LeftShoulder", Vector3(1.2, 0.18, ROAD_LENGTH), Vector3(-5.9, -0.18, -75), Color(0.72, 0.72, 0.66))
	_make_box(road_root, "RightShoulder", Vector3(1.2, 0.18, ROAD_LENGTH), Vector3(5.9, -0.18, -75), Color(0.72, 0.72, 0.66))
	_make_box(road_root, "LeftGrass", Vector3(28, 0.1, ROAD_LENGTH), Vector3(-20, -0.28, -75), Color(0.18, 0.38, 0.23))
	_make_box(road_root, "RightGrass", Vector3(28, 0.1, ROAD_LENGTH), Vector3(20, -0.28, -75), Color(0.18, 0.38, 0.23))

	for lane_x in [-1.6, 1.6]:
		for i in range(22):
			var mark := _make_box(road_root, "LaneMark", Vector3(0.12, 0.035, 3.6), Vector3(lane_x, -0.055, -i * 10.0 + 15), Color(0.92, 0.91, 0.78))
			road_marks.append(mark)

	# Simple roadside blocks give the highway depth and motion cues.
	for i in range(24):
		var z := -i * 9.0
		_make_box(road_root, "RoadsidePostL", Vector3(0.18, 1.3, 0.18), Vector3(-7.2, 0.45, z), Color(0.92, 0.87, 0.68))
		_make_box(road_root, "RoadsidePostR", Vector3(0.18, 1.3, 0.18), Vector3(7.2, 0.45, z), Color(0.92, 0.87, 0.68))
		if i % 2 == 0:
			_make_tree(Vector3(-10.0, 0, z - 2))
			_make_tree(Vector3(10.0, 0, z - 5))

	player = _make_car("PlayerCar", Color(0.88, 0.08, 0.09), false)
	player.position = Vector3(LANES[player_lane], 0, PLAYER_Z)

	camera_3d = Camera3D.new()
	camera_3d.position = Vector3(0, 7.6, 14.0)
	camera_3d.rotation_degrees = Vector3(-17, 0, 0)
	camera_3d.fov = 72
	add_child(camera_3d)
	camera_3d.current = true

func _make_box(parent: Node3D, node_name: String, size: Vector3, pos: Vector3, color: Color) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	instance.name = node_name
	var mesh := BoxMesh.new()
	mesh.size = size
	instance.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.8
	instance.material_override = mat
	instance.position = pos
	parent.add_child(instance)
	return instance

func _make_tree(pos: Vector3) -> void:
	_make_box(road_root, "TreeTrunk", Vector3(0.35, 1.5, 0.35), pos + Vector3(0, 0.7, 0), Color(0.28, 0.18, 0.1))
	var crown := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = 1.0
	mesh.height = 2.0
	crown.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.1, 0.32, 0.16)
	crown.material_override = mat
	crown.position = pos + Vector3(0, 2.0, 0)
	road_root.add_child(crown)

func _make_car(node_name: String, color: Color, police: bool) -> Node3D:
	var car := Node3D.new()
	car.name = node_name
	var body := _make_box(car, "Body", Vector3(1.45, 0.55, 2.65), Vector3(0, 0.62, 0), color)
	_make_box(car, "Cabin", Vector3(1.0, 0.45, 1.1), Vector3(0, 1.08, -0.12), Color(0.12, 0.2, 0.27))
	for x in [-0.77, 0.77]:
		for z in [-0.82, 0.82]:
			_make_box(car, "Wheel", Vector3(0.22, 0.42, 0.48), Vector3(x, 0.32, z), Color(0.06, 0.06, 0.07))
	_make_box(car, "FrontGlass", Vector3(0.72, 0.22, 0.06), Vector3(0, 1.15, 0.43), Color(0.48, 0.68, 0.76))
	if police:
		_make_box(car, "PoliceLightRed", Vector3(0.35, 0.12, 0.18), Vector3(-0.2, 1.34, -0.1), Color(1, 0.05, 0.04))
		_make_box(car, "PoliceLightBlue", Vector3(0.35, 0.12, 0.18), Vector3(0.2, 1.34, -0.1), Color(0.04, 0.35, 1))
	return car

func _build_ui() -> void:
	ui_layer = CanvasLayer.new()
	add_child(ui_layer)

	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_layer.add_child(root)

	hud_label = Label.new()
	hud_label.position = Vector2(20, 18)
	hud_label.add_theme_font_size_override("font_size", 25)
	hud_label.add_theme_color_override("font_color", Color.WHITE)
	hud_label.text = "DISTANCE 0 m   COINS 0   NITRO 100%"
	root.add_child(hud_label)

	message_label = Label.new()
	message_label.anchor_left = 0.1
	message_label.anchor_right = 0.9
	message_label.anchor_top = 0.33
	message_label.anchor_bottom = 0.5
	message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	message_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	message_label.add_theme_font_size_override("font_size", 29)
	message_label.add_theme_color_override("font_color", Color.WHITE)
	message_label.text = "HIGHWAY OVERDRIVE 3D\nDodge traffic • Collect coins • Escape police"
	root.add_child(message_label)

	overlay = ColorRect.new()
	overlay.color = Color(0.02, 0.04, 0.08, 0.78)
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(overlay)

	start_button = _make_button(root, "START RACE", Vector2(0.28, 0.52), Vector2(0.72, 0.59))
	start_button.pressed.connect(_start_or_resume)
	left_button = _make_button(root, "◀ LEFT", Vector2(0.03, 0.88), Vector2(0.25, 0.96))
	left_button.pressed.connect(_move_left)
	right_button = _make_button(root, "RIGHT ▶", Vector2(0.27, 0.88), Vector2(0.49, 0.96))
	right_button.pressed.connect(_move_right)
	nitro_button = _make_button(root, "⚡ NITRO", Vector2(0.52, 0.88), Vector2(0.75, 0.96))
	nitro_button.button_down.connect(_nitro_down)
	nitro_button.button_up.connect(_nitro_up)
	pause_button = _make_button(root, "Ⅱ", Vector2(0.83, 0.025), Vector2(0.97, 0.085))
	pause_button.pressed.connect(_toggle_pause)

func _make_button(parent: Control, text_value: String, top_left: Vector2, bottom_right: Vector2) -> Button:
	var button := Button.new()
	button.text = text_value
	button.anchor_left = top_left.x
	button.anchor_top = top_left.y
	button.anchor_right = bottom_right.x
	button.anchor_bottom = bottom_right.y
	button.offset_left = 0
	button.offset_top = 0
	button.offset_right = 0
	button.offset_bottom = 0
	button.add_theme_font_size_override("font_size", 21)
	parent.add_child(button)
	return button

func _start_or_resume() -> void:
	if game_over:
		_reset_game()
	paused_game = false
	overlay.visible = false
	message_label.visible = false
	start_button.text = "RESUME"
	get_tree().paused = false

func _reset_game() -> void:
	for item in traffic:
		if is_instance_valid(item.get("node")):
			item.node.queue_free()
	traffic.clear()
	distance = 0
	coins = 0
	nitro = 100
	heat = 0
	speed = 28
	spawn_timer = 0
	coin_timer = 0
	police_timer = 0
	boost_time = 0
	player_lane = 1
	player.position = Vector3(LANES[player_lane], 0, PLAYER_Z)
	game_over = false
	_update_hud()

func _move_left() -> void:
	if not game_over and not paused_game:
		player_lane = max(0, player_lane - 1)

func _move_right() -> void:
	if not game_over and not paused_game:
		player_lane = min(2, player_lane + 1)

func _nitro_down() -> void:
	boost_time = 999.0

func _nitro_up() -> void:
	boost_time = 0.0

func _toggle_pause() -> void:
	if game_over:
		return
	paused_game = not paused_game
	overlay.visible = paused_game
	message_label.visible = paused_game
	message_label.text = "PAUSED"
	start_button.text = "RESUME" if paused_game else "START RACE"

func _process(delta: float) -> void:
	if game_over or paused_game:
		return

	var boosting := boost_time > 0.0 and nitro > 0.0
	speed = min(42.0, speed + delta * 0.22)
	if boosting:
		nitro = max(0.0, nitro - 32.0 * delta)
	else:
		nitro = min(100.0, nitro + 5.5 * delta)
	var actual_speed := speed * (1.65 if boosting else 1.0)
	distance += actual_speed * delta * 0.75
	heat = max(0.0, heat - delta * 1.4)
	player.position.x = lerp(player.position.x, LANES[player_lane], min(1.0, delta * 9.0))

	for mark in road_marks:
		mark.position.z += actual_speed * delta
		if mark.position.z > 18:
			mark.position.z -= 220

	spawn_timer += delta
	coin_timer += delta
	police_timer += delta
	if spawn_timer > max(0.48, 1.35 - distance / 2500.0):
		spawn_timer = 0
		_spawn_traffic()
	if coin_timer > 1.15:
		coin_timer = 0
		_spawn_coin()
	if police_timer > 9.0 and heat > 10:
		police_timer = 0
		_spawn_police()

	_update_objects(delta)
	_update_hud()

func _spawn_traffic() -> void:
	var lane := randi_range(0, 2)
	var colors := [Color(0.92, 0.65, 0.15), Color(0.16, 0.55, 0.8), Color(0.75, 0.78, 0.82), Color(0.42, 0.35, 0.72), Color(0.15, 0.62, 0.35)]
	var car := _make_car("TrafficCar", colors.pick_random(), false)
	car.position = Vector3(LANES[lane], 0, -95)
	object_root.add_child(car)
	traffic.append({"node": car, "kind": "traffic", "lane": lane})

func _spawn_police() -> void:
	var lane := randi_range(0, 2)
	var car := _make_car("PoliceCar", Color(0.88, 0.9, 0.94), true)
	car.position = Vector3(LANES[lane], 0, -100)
	object_root.add_child(car)
	traffic.append({"node": car, "kind": "police", "lane": lane})

func _spawn_coin() -> void:
	var lane := randi_range(0, 2)
	var coin := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = 0.55
	mesh.bottom_radius = 0.55
	mesh.height = 0.12
	coin.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(1.0, 0.72, 0.08)
	mat.metallic = 0.65
	mat.roughness = 0.25
	coin.material_override = mat
	coin.rotation_degrees.x = 90
	coin.position = Vector3(LANES[lane], 1.15, -85)
	object_root.add_child(coin)
	traffic.append({"node": coin, "kind": "coin", "lane": lane})

func _update_objects(delta: float) -> void:
	for i in range(traffic.size() - 1, -1, -1):
		var item: Dictionary = traffic[i]
		var node: Node3D = item.node
		if not is_instance_valid(node):
			traffic.remove_at(i)
			continue
		var kind: String = item.kind
		node.position.z += speed * delta * (0.82 if kind == "police" else (1.0 if kind == "traffic" else 1.0))
		if kind == "coin" and abs(node.position.z - PLAYER_Z) < 2.0 and abs(node.position.x - player.position.x) < 1.5:
			coins += 1
			nitro = min(100.0, nitro + 7.0)
			node.queue_free()
			traffic.remove_at(i)
			continue
		if kind != "coin" and abs(node.position.z - PLAYER_Z) < 2.3 and abs(node.position.x - player.position.x) < 1.45:
			heat = min(100.0, heat + (34.0 if kind == "police" else 25.0))
			nitro = max(0.0, nitro - 18.0)
			node.queue_free()
			traffic.remove_at(i)
			if heat >= 100:
				_end_game("POLICE CAUGHT YOU!")
			continue
		if node.position.z > 22:
			node.queue_free()
			traffic.remove_at(i)

func _end_game(reason: String) -> void:
	game_over = true
	paused_game = false
	overlay.visible = true
	message_label.visible = true
	message_label.text = reason + "\nDistance: %d m   Coins: %d" % [int(distance), coins]
	start_button.text = "RACE AGAIN"

func _update_hud() -> void:
	hud_label.text = "DISTANCE %d m    COINS %d    NITRO %d%%" % [int(distance), coins, int(nitro)]
